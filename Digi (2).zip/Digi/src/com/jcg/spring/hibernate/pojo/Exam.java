package com.jcg.spring.hibernate.pojo;

import java.io.Serializable;
 
public class Exam implements Serializable {
 
    private static final long serialVersionUID = 1L;

    private int id;
    private String code,date,marks,eid;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getMarks() {
		return marks;
	}


	public void setMarks(String marks) {
		this.marks = marks;
	}


	public String getEid() {
		return eid;
	}


	public void setEid(String eid) {
		this.eid = eid;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	

}
