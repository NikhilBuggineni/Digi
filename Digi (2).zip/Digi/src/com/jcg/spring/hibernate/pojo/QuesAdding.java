package com.jcg.spring.hibernate.pojo;

import java.io.Serializable;




public class QuesAdding implements Serializable {

		@Override
	public String toString() {
		return "[qId='" + qId + "', mark='" + mark + "', question='" + question + "', a='" + a + "', b='" + b + "', c='"
				+ c + "', d='" + d + "', cId='" + cId + "', answer='" + answer + "']";
	}






		private static final long serialVersionUID = -3465813074586302847L;
		private int qId;	
		private int mark;
		private String question;
	     private String  a;
	     private String b;
	     private String c;
	     private String d;
	  	    private String cId;
	  private String answer;
		
		
	
		
	     public int getqId() {
			return qId;
		}




		public void setqId(int qId) {
			this.qId = qId;
		}




		public int getMark() {
			return mark;
		}




		public void setMark(int mark) {
			this.mark = mark;
		}




		public String getQuestion() {
			return question;
		}




		public void setQuestion(String question) {
			this.question = question;
		}




		public String getA() {
			return a;
		}




		public void setA(String a) {
			this.a = a;
		}




		public String getB() {
			return b;
		}




		public void setB(String b) {
			this.b = b;
		}




		public String getC() {
			return c;
		}




		public void setC(String c) {
			this.c = c;
		}




		public String getD() {
			return d;
		}




		public void setD(String d) {
			this.d = d;
		}




		public String getcId() {
			return cId;
		}




		public void setcId(String cId) {
			this.cId = cId;
		}




		public String getAnswer() {
			return answer;
		}




		public void setAnswer(String answer) {
			this.answer = answer;
		}


	

	

		public static long getSerialversionuid() {
			return serialVersionUID;
		}


	

}